
// Simple interactive stock dashboard
async function fetchData(){
  const res = await fetch('data.json');
  const data = await res.json();
  return data;
}

function formatNumber(n){ return (n===null||n===undefined||n==='') ? '-' : Number(n).toLocaleString(); }

function createElement(tag, attrs={}, ...children){
  const el = document.createElement(tag);
  for(const [k,v] of Object.entries(attrs||{})){
    if(k==='class') el.className = v;
    else if(k.startsWith('on') && typeof v === 'function') el.addEventListener(k.substring(2).toLowerCase(), v);
    else el.setAttribute(k,v);
  }
  children.flat().forEach(c => {
    if(typeof c === 'string' || typeof c === 'number') el.appendChild(document.createTextNode(String(c)));
    else if(c) el.appendChild(c);
  });
  return el;
}

function buildTable(records){
  const table = createElement('table',{class:'table'});
  const thead = createElement('thead',{}, createElement('tr',{},
    createElement('th',{},'Produto'),
    createElement('th',{},'Tipo'),
    createElement('th',{},'Quantidade'),
    createElement('th',{},'Data'),
    createElement('th',{},'Sheet')
  ));
  const tbody = createElement('tbody');
  records.forEach(r=>{
    const tr = createElement('tr',{},
      createElement('td',{}, r.produto||''),
      createElement('td',{}, r.tipo||''),
      createElement('td',{}, formatNumber(r.quantidade)),
      createElement('td',{}, r.data||''),
      createElement('td',{}, r.sheet||'')
    );
    tbody.appendChild(tr);
  });
  table.appendChild(thead);
  table.appendChild(tbody);
  return table;
}

function computeStock(records){
  const map = {};
  records.forEach(r=>{
    const prod = String(r.produto||'').trim() || '(SEM NOME)';
    const qty = Number(r.quantidade) || 0;
    const tipo = String(r.tipo||'').toLowerCase();
    let sign = 0;
    if(tipo.includes('entrada') || tipo.includes('in') || tipo.includes('receb') ) sign = 1;
    else if(tipo.includes('saida') || tipo.includes('saída') || tipo.includes('out') || tipo.includes('vend') ) sign = -1;
    else {
      sign = qty >= 0 ? 1 : -1;
    }
    const delta = sign * Math.abs(qty);
    if(!map[prod]) map[prod] = {produto:prod, saldo:0, entradas:0, saidas:0};
    map[prod].saldo += delta;
    if(delta>0) map[prod].entradas += delta;
    else map[prod].saidas += Math.abs(delta);
  });
  return Object.values(map).sort((a,b)=>b.saldo - a.saldo);
}

function renderDashboard(data){
  const root = document.getElementById('root');
  root.innerHTML = '';
  const header = createElement('div',{class:'header'}, createElement('div',{class:'container'}, createElement('h1',{},'Controle de Estoque — Moça Bonita (protótipo)')));
  root.appendChild(header);

  const container = createElement('div',{class:'container'});

  const controls = createElement('div',{class:'card controls'},
    createElement('div',{}, createElement('strong',{}, 'Filtros: ')),
    createElement('input',{type:'text',placeholder:'Filtrar por produto', id:'filterProduct'}),
    createElement('button',{class:'btn', onClick:()=>applyFilter()}, 'Aplicar')
  );

  container.appendChild(controls);

  const summaryCard = createElement('div',{class:'card grid'});
  const summary = computeStock(data.summary || []);
  const totalProducts = summary.length;
  const totalStock = summary.reduce((s,p)=>s + (Number(p.saldo)||0),0);
  const totalEntries = summary.reduce((s,p)=>s + (Number(p.entradas)||0),0);
  const totalExits = summary.reduce((s,p)=>s + (Number(p.saidas)||0),0);

  summaryCard.appendChild(createElement('div',{}, createElement('h3',{}, 'Resumo'),
    createElement('p',{}, 'Produtos únicos: '), createElement('strong',{}, totalProducts),
    createElement('p',{}, 'Estoque total (saldo): '), createElement('strong',{}, formatNumber(totalStock))
  ));
  summaryCard.appendChild(createElement('div',{}, createElement('h3',{}, 'Entradas'), createElement('p',{}, formatNumber(totalEntries))));
  summaryCard.appendChild(createElement('div',{}, createElement('h3',{}, 'Saídas'), createElement('p',{}, formatNumber(totalExits))));
  container.appendChild(summaryCard);

  const stockCard = createElement('div',{class:'card'}, createElement('h3',{}, 'Como está o estoque (por produto)'));
  const stockTable = createElement('table',{class:'table'});
  const thead = createElement('thead',{}, createElement('tr',{},
    createElement('th',{}, 'Produto'),
    createElement('th',{}, 'Saldo'),
    createElement('th',{}, 'Entradas'),
    createElement('th',{}, 'Saídas')
  ));
  const tbody = createElement('tbody');
  summary.forEach(p=>{
    tbody.appendChild(createElement('tr',{},
      createElement('td',{}, p.produto),
      createElement('td',{}, formatNumber(p.saldo)),
      createElement('td',{}, formatNumber(p.entradas)),
      createElement('td',{}, formatNumber(p.saidas))
    ));
  });
  stockTable.appendChild(thead); stockTable.appendChild(tbody);
  stockCard.appendChild(stockTable);
  container.appendChild(stockCard);

  const recordsCard = createElement('div',{class:'card'}, createElement('h3',{}, 'Registros (entradas/saídas)'));
  recordsCard.appendChild(buildTable(data.summary || []));
  container.appendChild(recordsCard);

  const topOut = summary.slice().sort((a,b)=>b.saidas - a.saidas).slice(0,6);
  const topIn = summary.slice().sort((a,b)=>b.entradas - a.entradas).slice(0,6);

  const infocard = createElement('div',{class:'card grid'});
  infocard.appendChild(createElement('div',{}, createElement('h3',{}, 'Top produtos - Saídas'), createElement('ol',{}, ...topOut.map(p=>createElement('li',{}, `${p.produto} — ${formatNumber(p.saidas)}`)))));
  infocard.appendChild(createElement('div',{}, createElement('h3',{}, 'Top produtos - Entradas'), createElement('ol',{}, ...topIn.map(p=>createElement('li',{}, `${p.produto} — ${formatNumber(p.entradas)}`)))));
  container.appendChild(infocard);

  container.appendChild(createElement('div',{class:'footer card small'}, 'Protótipo interativo gerado automaticamente — personalize para seu uso.'));

  root.appendChild(container);

  window._moca_data = data;
  window._moca_summary = summary;
}

function applyFilter(){
  const q = document.getElementById('filterProduct').value.toLowerCase().trim();
  const records = (window._moca_data && window._moca_data.summary) ? window._moca_data.summary : [];
  if(!q){ renderDashboard(window._moca_data); return; }
  const filtered = records.filter(r => (r.produto||'').toLowerCase().includes(q));
  renderDashboard({summary: filtered});
}

(async function(){
  try{
    const data = await fetchData();
    renderDashboard(data);
  }catch(err){
    document.getElementById('root').innerHTML = '<div style="padding:20px;">Erro ao carregar data.json — verifique se o arquivo existe. '+err+'</div>';
    console.error(err);
  }
})();
